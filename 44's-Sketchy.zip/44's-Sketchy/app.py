import cv2
import os
from werkzeug.utils import secure_filename
from flask import Flask, request, render_template, flash, redirect, url_for

UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = set(['png', 'jpg', 'jpeg'])

app = Flask(__name__)
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.secret_key = "secret key"

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def make_sketch(img):
    try:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        # Applying adaptive thresholding for better sketch results
        sketch = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 11, 2)
        return sketch
    except Exception as e:
        app.logger.error(f"Error in make_sketch: {e}")
        flash("An error occurred while processing the image. Please try again.", 'error')
        return None

@app.route('/')
def home():
    return render_template('home.html')

@app.route("/sketch", methods=['POST'])
def sketch():
    try:
        file = request.files['file']
        if file.filename == '':
            flash('No file selected', 'error')
            return redirect(request.url)

        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            img = cv2.imread(os.path.join(app.config['UPLOAD_FOLDER'], filename))

            sketch_img = make_sketch(img)
            if sketch_img is None:
                return redirect(request.url)

            sketch_img_name = filename.split('.')[0] + "_sketch.jpg"
            _ = cv2.imwrite(os.path.join(app.config['UPLOAD_FOLDER'], sketch_img_name), sketch_img)
            return render_template('home.html', org_img_name=filename, sketch_img_name=sketch_img_name)
        else:
            flash('Invalid file format. Please upload a PNG, JPG, or JPEG file.', 'error')
            return redirect(request.url)
    except Exception as e:
        app.logger.error(f"Error in sketch route: {e}")
        flash("An error occurred while processing the image. Please try again.", 'error')
        return redirect(request.url)

if __name__ == '__main__':
    app.run(debug=True)


